﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BigBlock : MonoBehaviour {

    public GameObject campFire;
    public bool scared = true;
    Rigidbody2D body2D;

	// Use this for initialization
	void Start () {
        body2D = GetComponent<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void Update () {
	
        if(scared == true && campFire.GetComponent<CampFire>().lit == true)
        {

            body2D.AddForce(new Vector2(1f, 0f));

        }

	}

    private void OnTriggerEnter2D(Collider2D collision)
    {
        print("hit");
        print(collision.gameObject.tag);
        if(collision.gameObject.tag == "Campfire")
        {
            print("hitting camp");
            scared = true;
        }
    }
}
