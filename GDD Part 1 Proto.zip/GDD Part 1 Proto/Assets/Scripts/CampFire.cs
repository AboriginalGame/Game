﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class CampFire : MonoBehaviour {

    public bool lit;


    public GameObject Player;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

        lit = GetComponent<Animator>().GetBool("Alight");

    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Player" && Player.GetComponent<Player>().hasTorch == true)
        {
            GetComponent<Animator>().SetBool("Alight", true);

        }
    }

    
}
