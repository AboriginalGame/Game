﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovetoS: MonoBehaviour
{

    bool spawned = false;

    public GameObject StoneP;

    public GameObject Alien;

    public GameObject Player;

    float speed = 10f;

    public bool destruct = false;

    Vector2 target;

    // Use this for initialization
    void Start()
    {

        

    }

    // Update is called once per frame
    void Update()
    {

        Alien = GameObject.FindGameObjectWithTag("Alien");

        ThrowSpear actSpear = Alien.GetComponent<ThrowSpear>();

        Player = GameObject.FindGameObjectWithTag("Player");

        


        if (spawned == false)
        {
            StoneP = GameObject.FindGameObjectWithTag("Spear");

            target = new Vector2(StoneP.transform.position.x, StoneP.transform.position.y);

            spawned = true;
        }

       float step = speed * Time.deltaTime;

         StoneP.transform.position = Vector2.MoveTowards(StoneP.transform.position, transform.position, step);

       // transform.position = Vector2.Lerp(transform.position, StoneP.transform.position, Time.time);

        if(StoneP.transform.position == transform.position)
        {

            actSpear.reset = true;
            destruct = true;
            
        }

        if(destruct == true)
        {
            Player.GetComponent<throwStone>().thrown = true;
            Destroy(StoneP);
            Destroy(gameObject);
        }

    }
}
