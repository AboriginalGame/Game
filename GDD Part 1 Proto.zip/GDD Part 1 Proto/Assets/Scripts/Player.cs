﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

    Rigidbody2D body2D;
    public float xSpeed = 0f;
    public float ySpeed = 0f;
    public float thrust = 300f;

    public bool grounded = false;
    public bool hasTorch;

    public int jCount = 0;
    public float jCountMax = 7f;

    bool jump = false;

	// Use this for initialization
	void Start () {

        body2D = GetComponent<Rigidbody2D>();
		
	}
	
	// Update is called once per frame
	void Update () {

        body2D.AddForce(new Vector2(xSpeed, ySpeed) * thrust * Time.deltaTime);

        if (Input.GetKey(KeyCode.A))
        {
            xSpeed = -1f;
        }

        if (Input.GetKey(KeyCode.D))
        {
            xSpeed = 1f;
        }

        if (Input.GetKeyUp(KeyCode.A))
        {
            xSpeed = 0f;
        }

        if (Input.GetKeyUp(KeyCode.D))
        {
            xSpeed = 0f;
        }

        if (Input.GetKeyUp(KeyCode.Space) && grounded == true)
        {
            jump = true;        
        }

        if(jump == true)
        {
            jCount += 1;
            ySpeed = 10f;
        }

        if (jCount >= jCountMax)
        {
            grounded = false;
            jCount = 0;
            jump = false;
        }

        if (grounded == false)
        {
            ySpeed = 0f;
            
        }

        




    }

    void OnCollisionStay2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Ground")
        {
            grounded = true;
            
        }

        
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Campfire")
        {
            GetComponent<Animator>().SetBool("campFire", true);
            hasTorch = GetComponent<Animator>().GetBool("campFire");
            

        }

        
    }
}
